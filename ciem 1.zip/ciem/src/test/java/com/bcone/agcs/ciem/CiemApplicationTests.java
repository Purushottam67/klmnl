package com.bcone.agcs.ciem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CiemApplicationTests {

	@Test
	void contextLoads() {
	}

}
