package com.bcone.agcs.ciem.utils;

public class CiemConstant {
    public static final String SLASH = "/";
    public static final String USERID = "__USERID__";
    public static final String ROLEID = "__ROLEID__";
    public static final String APPID = "__APPID__";
}
