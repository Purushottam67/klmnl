package com.bcone.agcs.ciem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CiemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CiemApplication.class, args);
	}

}
